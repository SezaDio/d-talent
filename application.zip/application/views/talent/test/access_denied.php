<div class="online-test access-denied">
	<div class="test-title">
		<h3 class="text-center">
			<b>ACCESS DENIED</b>
		</h3>
	</div>
	
	<hr>
	
	<div>
		<p class="text-access-denied text-center">
			Sorry, You can't take this test because you have been took this test
		</p>
	</div>

	<hr class="bottom-line">

	<!-- page button -->
	<div class="test-footer text-center">
		<a href="<?php echo site_url('talent');?>"><button type="button" class="btn button1">Back to My CV</button></a>
	</div>

</div>
