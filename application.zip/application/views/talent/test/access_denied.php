<div class="access-denied" style="padding-top: 15px; padding-bottom: 15px; min-height: 500px;">
	<div class="container">
		<div class="card center-block" style="box-shadow: 1px 5px 20px lightgrey;">
			<div class="card-body">
				<div class="test">
					<p class="text-center">
						Anda tidak dapat mengakses tes online karena telah mengerjakan tes ini
					</p>
				</div>
			</div>

			<br>
			<div class="row">
				<div class="col-md-4"></div>
				<div class="col-md-4">
					<div style="text-align: center;">
						<a href="<?php echo site_url('talent');?>"><button type="button" class="button button1">Back to My CV</button></a>
					</div>
				</div>
				<div class="col-md-4"></div>
			</div>

		</div>
	</div>
</div>
