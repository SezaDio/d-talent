<html>
	<head>
		<title> Belajar CI </title>
	</head>
	<body>
		<a href="http://www.adrianhartanto.com">
			<h1> Greetings From Code Igniter</h1>
		</a>
	</body>
</html>