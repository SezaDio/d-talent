<!DOCTYPE html>
<html>
	<head>
		<title>Talent Respon Decline | D-Talent</title>
		<script type="text/javascript" src="<?php echo base_url('asset/bootstrap/js/bootstrap.js'); ?>"></script>
		<link href="<?php echo base_url('asset/bootstrap/css/bootstrap.min.css'); ?>" rel="stylesheet">
		<link href="<?php echo base_url('asset/bootstrap/css/bootstrap-theme.min.css'); ?>" rel="stylesheet">
		<link href="<?php echo base_url('asset/bootstrap/css/style.css'); ?>" rel="stylesheet">
	</head>
	<body style="background: whitesmoke;">
		<div class="container">
			<div class="row" style="padding: 10px;">
				<br><br><br><br><br><br>
				<div class="col-lg-4">
				</div>

				<div class="col-lg-4" style="padding: 20px; background: white; border: solid 1px lightgray; border-radius: 5px; box-shadow: 0px 0px 50px dimgrey;">
					<div class="omb_login">	
						<hr style="border: solid 1px black">
						<div class="row">
							<div class="col-md-12" style="text-align: center; font-family: monospace;">
								<h2><strong><u>TERIMA KASIH</u></strong></h2>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12" style="text-align: center;">
								<h4 style="font-family: sans-serif;">Respon <b style="color: red;">Decline</b> anda telah kami terima.</h4>
							</div>
						</div>
						<hr style="border: solid 1px black">
						<div class="row">
							<div class="col-md-12" style="text-align: center;">
								<div class="copyright">
					              <p style="color: darkgray;">All copyrights reserved &copy; 2018<br>Designed & Developed by IT Team D-Talent</a></p>
					            </div>
							</div>
						</div>
					</div>
				</div>

				<div class="col-lg-4">
				</div>
			</div>
        </div>
	</body>
</html>