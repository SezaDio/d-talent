<table style="padding: 10px; width: 100%;">
	<tr>
		<td>
			<p style="text-align: center;">
				Terima kasih telah menyelesaikan proses pembayaran<br>
				Silahkan cetak atau simpan bukti transaksi anda dengan menekan tombol di bawah ini
				<br>
				<a href="<?php echo $link_invoice; ?>">
					<button style="background-color: #f44a56; color: white; width: 150px; height: 40px; border: none;border-radius: 5px; font-size: 1em;">Bukti Transaksi</button>
				</a>
			</p>
		</td>
	</tr>
</table>